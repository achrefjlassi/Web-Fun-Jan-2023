var x = document.getElementById("myVideo");
function playVid() {
    x.play();
  }
  
  function pauseVid() {
    x.pause();
  }